# Classic Ludo

A standalone, no-login Ludo game for GitHub Pages.

## Play locally

Open `index.html` in a modern browser. No installation, server, account, or internet connection is required after the file is downloaded.

## Publish with GitHub Pages

1. Create or open a GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select the `main` branch and `/ (root)`, then save.
5. Open the Pages URL shown by GitHub after the deployment completes.

## Modes

- 1 vs 3: one human and three CPU players
- 2 vs 2: two human players and two CPU players
- 3 vs 1: three human players and one CPU player
- 4 players: four human players sharing one device

Human players use pass-and-play on the same device. CPU players roll and move automatically.
